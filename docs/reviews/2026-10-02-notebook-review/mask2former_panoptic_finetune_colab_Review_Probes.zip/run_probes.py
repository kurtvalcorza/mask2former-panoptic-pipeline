"""Review probes for tutorials/mask2former_panoptic_finetune_colab.ipynb (row 44, prefix M2F).

Direct execution on the review workstation CPU (CUDA_VISIBLE_DEVICES=-1), NOT Colab.
Usage: python run_probes.py <repo_worktree> <weights_src_dir> <scratch_dir>
The notebook's code cells run in order in one namespace (install skipped through the notebook's own
DIMER_NOTEBOOK_CI_PREINSTALLED switch; `display` and `google.colab.files` shimmed). Weights are pre-copied
from a local clone so `stage_missing_files` fetches nothing; `verify_snapshot` still re-hashes all four.
"""
from __future__ import annotations

import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
import types
import zipfile
from pathlib import Path

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"

REPO = Path(sys.argv[1]).resolve()
WEIGHTS_SRC = Path(sys.argv[2]).resolve()
SCRATCH = Path(sys.argv[3]).resolve()
NB_REL = "tutorials/mask2former_panoptic_finetune_colab.ipynb"
NB_PATH = REPO / NB_REL
results: dict = {"env": {"python": sys.version.split()[0], "executable": sys.executable}}


def save():
    (SCRATCH / "results.json").write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]

# ---------------- P01 static ----------------
p01: dict = {}
p01["blob"] = subprocess.run(["git", "-C", str(REPO), "hash-object", str(NB_PATH)], capture_output=True, text=True).stdout.strip()
p01["n_cells"], p01["n_code"] = len(cells), len(code_idx)
p01["compile_errors"] = []
for i in code_idx:
    try:
        compile("".join(cells[i]["source"]), f"cell{i}", "exec")
    except SyntaxError as exc:
        p01["compile_errors"].append((i, str(exc)))
p01["embedded_module_lines"] = {
    i: "".join(cells[i]["source"]).count("\n") + 1
    for i in code_idx
    if cells[i].get("metadata", {}).get("dimer", {}).get("embedded_module")
}
p01["code_cells_form_or_collapsed"] = [
    i
    for i in code_idx
    if cells[i].get("metadata", {}).get("cellView") == "form"
    or cells[i].get("metadata", {}).get("collapsed")
    or cells[i].get("metadata", {}).get("jupyter", {}).get("source_hidden")
]
p01["code_cells_with_title"] = [i for i in code_idx if "# @title" in "".join(cells[i]["source"])]
md = "\n".join("".join(c["source"]) for c in cells if c["cell_type"] == "markdown")
alltext = "\n".join("".join(c["source"]) for c in cells)
p01["keyword_counts_markdown"] = {
    k: md.count(k)
    for k in [
        "How to use", "oadmap", "lossary", "redict", "Check your", "<details", "roubleshoot",
        "What to notice", "Expected result", "Infrastructure", "onclusion", "Look for", "re-run",
        "rerun", "Restart", "_max_size", "overflow", "slow image processor",
    ]
}
p01["metadata_dimer"] = nb["metadata"].get("dimer")
p01["env_vars_read"] = sorted(set(re.findall(r"os\.environ\.get\('([A-Z_]+)'", alltext)))
p01["env_var_in_markdown"] = "DIMER_NOTEBOOK_CI_PREINSTALLED" in md
p01["param_cells"] = {
    i: re.findall(r"^(\w+) = .*# @param", "".join(cells[i]["source"]), re.M)
    for i in code_idx
    if "@param" in "".join(cells[i]["source"])
}
for name, cmd in {
    "build_notebook_check_finetune": [sys.executable, "tools/build_notebook.py", "--template", "tools/notebook_template_finetune.py", "--check"],
    "validate_release_assets": [sys.executable, "tools/validate_release_assets.py"],
}.items():
    r = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True, encoding="utf-8", errors="replace")
    p01[name] = {"rc": r.returncode, "tail": (r.stdout + r.stderr)[-500:]}
results["P01_static"] = p01
save()

# ---------------- harness ----------------
work = SCRATCH / "run"
if work.exists():
    shutil.rmtree(work)
wdir = work / "weights" / "mask2former-swin-tiny-coco-panoptic"
wdir.mkdir(parents=True)
for f in ["README.md", "config.json", "model.safetensors", "preprocessor_config.json"]:
    shutil.copy2(WEIGHTS_SRC / f, wdir / f)
os.chdir(work)

UPLOAD: dict = {}
colab = types.ModuleType("google.colab")
colab.files = types.SimpleNamespace(upload=lambda: dict(UPLOAD))
google = types.ModuleType("google")
google.colab = colab
sys.modules["google"] = google
sys.modules["google.colab"] = colab
ns: dict = {"__name__": "__main__", "display": lambda *a, **k: None}


def run_cell(i, overrides=None):
    src = "".join(cells[i]["source"])
    if overrides:
        out = []
        for line in src.split("\n"):
            for k, v in overrides.items():
                if line.startswith(f"{k} = ") and "@param" in line:
                    line = f"{k} = {v!r}  # overridden by probe"
            out.append(line)
        src = "\n".join(out)
    t0 = time.time()
    buf, old = io.StringIO(), sys.stdout
    sys.stdout = buf
    err = None
    try:
        exec(compile(src, f"cell{i}", "exec"), ns)
    except BaseException as exc:  # noqa: BLE001
        err = f"{type(exc).__name__}: {exc}"
    finally:
        sys.stdout = old
    return {"cell": i, "seconds": round(time.time() - t0, 2), "error": err, "stdout_tail": buf.getvalue()[-600:]}


def q(d):
    if d is None:
        return None
    return {
        "pq": round(d["pq"], 4), "sq": round(d["sq"], 4), "rq": round(d["rq"], 4),
        "per_class_pq": {k: round(v["pq"], 3) for k, v in d["per_class"].items()},
    }


# ---------------- P02 clean default ----------------
p02: dict = {"cells": []}
t0 = time.time()
for i in code_idx:
    p02["cells"].append(run_cell(i))
    results["P02_default"] = p02
    save()
p02["wall_s"] = round(time.time() - t0, 1)
p02["ok_cells"] = sum(1 for c in p02["cells"] if c["error"] is None)
p02["fetched"] = ns.get("fetched")
p02["coco_observation"] = ns.get("coco_observation")
p02["trivial"], p02["baseline"], p02["adapted"] = q(ns.get("trivial")), q(ns.get("baseline")), q(ns.get("adapted"))
run = ns.get("run") or {}
p02["run"] = {k: run.get(k) for k in ("epochs", "steps", "seconds", "trainable_parameters", "device")}
p02["run"]["history"] = [round(h["mean_loss"], 3) for h in run.get("history", [])]
p02["new_data_pq"] = round(ns["new_quality"]["pq"], 4) if ns.get("new_quality") else None
p02["outputs"] = sorted(os.listdir("outputs")) if Path("outputs").exists() else []
results["P02_default"] = p02
save()

# ---------------- P06 claim: is all-sky the meaningful trivial baseline? ----------------
try:
    import numpy as np

    held, train = ns["held_out"], ns["train_records"]
    C, S = ns["SHAPE_CLASSES"], ns["SHAPE_STUFF"]
    ref = ns["reference_from_record"]
    rows = []
    for r in train:  # horizon from the training split only
        gid = [k for k, v in r["instances"].items() if v == "ground"][0]
        rows.append(int(np.argmax((r["instance_map"] == gid).any(axis=1))))
    h = int(round(float(np.mean(rows))))
    pairs = []
    for r in held:
        rm, rs = ref(r, C, S)
        seg = np.ones_like(rm)
        seg[h:, :] = 2
        pairs.append((seg, [{"id": 1, "label": "sky", "is_thing": False}, {"id": 2, "label": "ground", "is_thing": False}], rm, rs))
    hz = ns["panoptic_quality"](pairs)
    results["P06_horizon_baseline"] = {
        "horizon_row_from_train": h, "pq": round(hz["pq"], 4), "stuff_pq": round(hz["stuff"]["pq"], 4),
        "per_class_pq": {k: round(v["pq"], 3) for k, v in hz["per_class"].items()},
        "all_sky_pq": round(ns["trivial"]["pq"], 4),
    }
except BaseException as exc:  # noqa: BLE001
    results["P06_horizon_baseline"] = {"error": f"{type(exc).__name__}: {exc}"}
save()

# ---------------- P03 active learning: "set EPOCHS to 2 and watch PQ fall" ----------------
p03: dict = {}
default_adapted_pq = ns["adapted"]["pq"]
# (a) EPOCHS lives in Section 5 (cell 13): re-run it, then the fine-tune and evaluate cells (17, 19)
a = [run_cell(13, {"EPOCHS": 2}), run_cell(17), run_cell(19)]
p03["a_rerun_13_17_19"] = {
    "errors": [c for c in a if c["error"]],
    "epoch_mean_losses": [round(h["mean_loss"], 3) for h in ns["run"]["history"]],
    "run_record_epochs": ns["run"]["epochs"], "run_record_steps": ns["run"]["steps"],
    "adapted_pq": round(ns["adapted"]["pq"], 4), "default_adapted_pq": round(default_adapted_pq, 4),
    "epochs_actually_applied_to_adapter": 6 + 2, "fine_tune_stdout": a[1]["stdout_tail"][-300:],
}
results["P03_active"] = p03
save()
# (b) same change, re-running from Section 5 through Section 8 (13, 15, 17, 19): fresh re-headed model
b = [run_cell(i, {"EPOCHS": 2} if i == 13 else None) for i in (13, 15, 17, 19)]
p03["b_rerun_13_15_17_19"] = {
    "errors": [c for c in b if c["error"]],
    "epoch_mean_losses": [round(h["mean_loss"], 3) for h in ns["run"]["history"]],
    "adapted": q(ns["adapted"]), "baseline_pq": round(ns["baseline"]["pq"], 4),
}
save()

# ---------------- P04 reuse / recovery ----------------
from PIL import Image  # noqa: E402

p04: dict = {}
results["P04_byod"] = p04


def byod(label, payload, overrides):
    UPLOAD.clear()
    UPLOAD.update(payload)
    r = run_cell(27, overrides)
    p04[label] = {"error": r["error"], "seconds": r["seconds"], "stdout_tail": r["stdout_tail"][-400:]}
    save()


def dataset_zip(n=8, seed=7, mutate=None, drop_json=False, extra=None):
    recs = ns["shape_dataset"](n, seed=seed)
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as zf:
        spec = {"class_names": list(ns["SHAPE_CLASSES"]), "stuff_names": list(ns["SHAPE_STUFF"]), "records": []}
        for r in recs:
            im, mk = io.BytesIO(), io.BytesIO()
            r["image"].save(im, format="PNG")
            m = r["instance_map"].astype("uint8")
            if mutate:
                m = mutate(m)
            Image.fromarray(m, mode="L").save(mk, format="PNG")
            zf.writestr(f"mine/images/{r['id']}.png", im.getvalue())
            zf.writestr(f"mine/masks/{r['id']}.png", mk.getvalue())
            spec["records"].append({"id": r["id"], "image": f"images/{r['id']}.png", "mask": f"masks/{r['id']}.png",
                                    "instances": {str(k): v for k, v in r["instances"].items()}})
        if not drop_json:
            zf.writestr("mine/dataset.json", json.dumps(spec))
        for name, data in (extra or {}).items():
            zf.writestr(name, data)
    return b.getvalue()


ON_DS = {"USE_BYOD_DATASET": True, "BYOD_EPOCHS": 1}
ON_IM = {"USE_BYOD_IMAGE": True}
for name in ("byod_baseline", "byod_adapted"):
    ns.pop(name, None)
# (a) representative own labelled directory: 8 drawn scenes written as PNG images + L-mode instance PNGs, 1 epoch
byod("dataset_ok_8_records_1_epoch", {"mine.zip": dataset_zip()}, ON_DS)
if ns.get("byod_adapted") is not None:
    d = p04["dataset_ok_8_records_1_epoch"]
    d["baseline_pq"] = round(ns["byod_baseline"]["pq"], 4)
    d["adapted_pq"] = round(ns["byod_adapted"]["pq"], 4)
    d["byod_trivial_baseline_names_in_namespace"] = [k for k in ns if k.startswith("byod_") and "trivial" in k]
    d["outputs_after"] = sorted(os.listdir("outputs"))
    d["byod_json_reports_written"] = [p for p in os.listdir("outputs") if p.endswith(".json") and "byod" in p]
# (b) member '../byod_dataset_evil/x.txt' shares the target's string prefix: where does it land?
byod("zip_member_prefix_sibling", {"evil.zip": dataset_zip(n=3, extra={"../byod_dataset_evil/x.txt": b"x"})}, ON_DS)
p04["zip_member_prefix_sibling"]["sibling_dir_created"] = Path("byod_dataset_evil").exists()
p04["zip_member_prefix_sibling"]["x_txt_inside_target"] = (
    [str(p.relative_to(Path("byod_dataset"))) for p in Path("byod_dataset").rglob("x.txt")] if Path("byod_dataset").exists() else []
)
save()
# (c) archive without dataset.json
byod("dataset_zip_without_dataset_json", {"nojson.zip": dataset_zip(n=3, drop_json=True)}, ON_DS)


def unassign(m):
    m = m.copy()
    m[0, 0] = 0
    return m


# (d) a mask with one unassigned pixel
byod("dataset_unassigned_pixel", {"bad.zip": dataset_zip(n=3, mutate=unassign)}, ON_DS)
# (e) cancelled upload
byod("dataset_empty_upload", {}, ON_DS)
# (f) BYOD image: one drawn scene (accepted), a text file, a cancelled upload
sc = ns["shape_dataset"](1, seed=99)[0]["image"]
bb = io.BytesIO()
sc.save(bb, format="PNG")
byod("image_ok", {"scene.png": bb.getvalue()}, ON_IM)
byod("image_not_an_image", {"notes.txt": b"hello"}, ON_IM)
byod("image_empty_upload", {}, ON_IM)
results["finished"] = True
save()
print("done")

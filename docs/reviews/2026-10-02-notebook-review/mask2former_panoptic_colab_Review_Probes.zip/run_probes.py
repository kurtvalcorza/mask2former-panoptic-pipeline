"""Review probes for tutorials/mask2former_panoptic_colab.ipynb (row 43, prefix M2P).

Direct execution on the review workstation CPU (CUDA_VISIBLE_DEVICES=-1), NOT Colab.
Usage: python run_probes.py <repo_worktree> <weights_src_dir> <scratch_dir>
The notebook's code cells are executed in order in one namespace (install skipped through the
notebook's own DIMER_NOTEBOOK_CI_PREINSTALLED switch; `display` and `google.colab.files` shimmed).
Weights are pre-copied from a local clone so `stage_missing_files` fetches nothing; the snapshot is
still re-verified by the notebook's own `verify_snapshot`.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import time
import types
from pathlib import Path

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"

REPO = Path(sys.argv[1]).resolve()
WEIGHTS_SRC = Path(sys.argv[2]).resolve()
SCRATCH = Path(sys.argv[3]).resolve()
NB_PATH = REPO / "tutorials" / "mask2former_panoptic_colab.ipynb"
results: dict = {"env": {"python": sys.version.split()[0], "executable": sys.executable}}


def save():
    (SCRATCH / "results.json").write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]

# ---------------- P01 static ----------------
p01: dict = {}
p01["blob"] = subprocess.run(["git", "-C", str(REPO), "hash-object", str(NB_PATH)], capture_output=True, text=True).stdout.strip()
p01["n_cells"] = len(cells)
p01["n_code"] = len(code_idx)
p01["n_markdown"] = len(cells) - len(code_idx)
compile_errors = []
for i in code_idx:
    try:
        compile("".join(cells[i]["source"]), f"cell{i}", "exec")
    except SyntaxError as exc:
        compile_errors.append((i, str(exc)))
p01["compile_errors"] = compile_errors
p01["embedded_module_lines"] = {
    i: "".join(cells[i]["source"]).count("\n") + 1 for i in code_idx if cells[i].get("metadata", {}).get("dimer", {}).get("embedded_module")
}
p01["code_cells_with_cellView_form_or_collapsed"] = [
    i for i in code_idx if cells[i].get("metadata", {}).get("cellView") == "form" or cells[i].get("metadata", {}).get("collapsed") or cells[i].get("metadata", {}).get("jupyter", {}).get("source_hidden")
]
p01["code_cells_with_title"] = [i for i in code_idx if "# @title" in "".join(cells[i]["source"])]
alltext = "\n".join("".join(c["source"]) for c in cells)
md = "\n".join("".join(c["source"]) for c in cells if c["cell_type"] == "markdown")
for key in ["How to use", "Roadmap", "roadmap", "Glossary", "glossary", "Predict", "predict", "Check your", "<details",
            "Troubleshoot", "troubleshoot", "What to notice", "Expected result", "Infrastructure", "conclusion", "Conclusion", "Look for", "workshop"]:
    p01.setdefault("keyword_counts_markdown", {})[key] = md.count(key)
p01["metadata_dimer"] = nb["metadata"].get("dimer")
p01["env_vars_read"] = sorted(set(__import__("re").findall(r"os\.environ\.get\('([A-Z_]+)'", alltext)))
p01["mentions_DIMER_NOTEBOOK_CI_PREINSTALLED_in_markdown"] = "DIMER_NOTEBOOK_CI_PREINSTALLED" in md
for name, cmd in {
    "build_notebook_check": [sys.executable, "tools/build_notebook.py", "--check"],
    "validate_release_assets": [sys.executable, "tools/validate_release_assets.py"],
}.items():
    r = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True, encoding="utf-8", errors="replace")
    p01[name] = {"rc": r.returncode, "tail": (r.stdout + r.stderr)[-600:]}
results["P01_static"] = p01
save()

# ---------------- execution harness ----------------
work = SCRATCH / "run"
if work.exists():
    shutil.rmtree(work)
(work / "weights" / "mask2former-swin-tiny-coco-panoptic").mkdir(parents=True)
for f in ["README.md", "config.json", "model.safetensors", "preprocessor_config.json"]:
    shutil.copy2(WEIGHTS_SRC / f, work / "weights" / "mask2former-swin-tiny-coco-panoptic" / f)
os.chdir(work)

UPLOAD: dict = {}
colab = types.ModuleType("google.colab")
files_mod = types.SimpleNamespace(upload=lambda: dict(UPLOAD))
colab.files = files_mod
google = types.ModuleType("google")
google.colab = colab
sys.modules["google"] = google
sys.modules["google.colab"] = colab

ns: dict = {"__name__": "__main__", "display": lambda *a, **k: None}


def run_cell(i, overrides=None):
    src = "".join(cells[i]["source"])
    if overrides:
        lines = []
        for line in src.split("\n"):
            for k, v in overrides.items():
                if line.startswith(f"{k} = ") and "@param" in line:
                    line = f"{k} = {v!r}  # overridden by probe"
            lines.append(line)
        src = "\n".join(lines)
    t0 = time.time()
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    err = None
    try:
        exec(compile(src, f"cell{i}", "exec"), ns)
    except BaseException as exc:  # noqa: BLE001
        err = f"{type(exc).__name__}: {exc}"
    finally:
        sys.stdout = old
    return {"cell": i, "seconds": round(time.time() - t0, 2), "error": err, "stdout_tail": buf.getvalue()[-700:]}


def summary():
    r = ns.get("result")
    rep = ns.get("report")
    return {
        "n_segments": None if r is None else len(r["segments"]),
        "segments": None if r is None else [(s["label"], round(s["score"], 3), round(s["area_fraction"], 3)) for s in r["segments"]],
        "void_fraction": None if r is None else round(r["void_fraction"], 3),
        "verdict": None if rep is None else rep["verdict"],
        "metrics": None if rep is None else {m["id"]: m["value"] for m in rep["metrics"]},
        "degenerate": ns.get("degenerate"),
        "photo_segments": (ns.get("photo_observation") or {}).get("segments"),
        "photo_void": (ns.get("photo_observation") or {}).get("void_fraction"),
    }


def result_json():
    p = Path("outputs/mask2former_panoptic_result.json")
    if not p.exists():
        return None
    d = json.loads(p.read_text(encoding="utf-8"))
    return {"thresholds": d["thresholds"], "n_segments": len(d["segments"]), "sample": d["sample"], "verdict": d["evaluation_report"]["verdict"], "mtime": p.stat().st_mtime}


# ---------------- P02 clean default (all code cells) ----------------
p02 = {"cells": []}
t0 = time.time()
for i in code_idx:
    p02["cells"].append(run_cell(i))
p02["wall_s"] = round(time.time() - t0, 1)
p02["ok_cells"] = sum(1 for c in p02["cells"] if c["error"] is None)
p02["summary"] = summary()
p02["fetched"] = ns.get("fetched")
p02["outputs"] = sorted(os.listdir("outputs")) if Path("outputs").exists() else []
p02["result_json"] = result_json()
p02["device"] = getattr(ns.get("pipe"), "device", None)
results["P02_default"] = p02
save()

# ---------------- P05 claim: pinned transformers post-processor area ----------------
try:
    import torch

    pipe = ns["pipe"]
    rgb = ns["image"].convert("RGB")
    inputs = pipe.processor(images=rgb, return_tensors="pt")
    with torch.inference_mode():
        out = pipe.model(pixel_values=inputs["pixel_values"], pixel_mask=inputs.get("pixel_mask"))
    pp = pipe.processor.post_process_panoptic_segmentation(out, threshold=0.5, mask_threshold=0.5, overlap_mask_area_threshold=0.8, target_sizes=[(rgb.height, rgb.width)])[0]
    seg = pp["segmentation"].numpy()
    info = []
    for s in pp["segments_info"]:
        info.append({"label": pipe.model.config.id2label[s["label_id"]], "score": round(float(s["score"]), 3), "area_fraction": round(float((seg == s["id"]).mean()), 3)})
    results["P05_transformers_postprocess"] = {"segments": info, "unassigned_fraction": round(float((seg <= 0).mean() if (seg == 0).any() and not any(s["id"] == 0 for s in pp["segments_info"]) else (seg == -1).mean()), 3)}
except BaseException as exc:  # noqa: BLE001
    results["P05_transformers_postprocess"] = {"error": f"{type(exc).__name__}: {exc}"}
save()

# ---------------- P03 active learning: documented 'Next experiments' ----------------
downstream = [i for i in code_idx if i >= 11]
p03 = {}
for label, ov in {
    "score_0.8": {"score_threshold": 0.8},
    "score_0.3": {"score_threshold": 0.3},
    "mask_0.3": {"mask_threshold": 0.3},
}.items():
    before = result_json()
    cell_runs = [run_cell(i, ov if i == 11 else None) for i in downstream]
    p03[label] = {"errors": [c for c in cell_runs if c["error"]], "summary": summary(), "result_json": result_json(), "result_json_before": before}
# stale-output check: change the form value and run only the segment cell (15), as a learner might
before = result_json()
_ = run_cell(11, {"score_threshold": 0.3})
_ = run_cell(15)
p03["only_cells_11_15_rerun"] = {"in_memory_n_segments": len(ns["result"]["segments"]), "report_thresholds_in_memory": ns["report"]["thresholds"], "result_json_on_disk": result_json(), "result_json_unchanged": before == result_json()}
results["P03_active"] = p03
save()

# ---------------- P04 reuse / recovery: BYOD branch with the upload shim ----------------
from PIL import Image  # noqa: E402

photo_bytes = None
if ns.get("photo_result") is not None:
    pass
coco = Path("coco.jpg")
photo = ns.get("photo")
p04 = {}


def byod(label, payload: dict, cells_to_run):
    UPLOAD.clear()
    UPLOAD.update(payload)
    runs = [run_cell(i, {"USE_BYOD": True, "FETCH_PUBLIC_PHOTO": False} if i in (11, 17) else None) for i in cells_to_run]
    first_err = next((c for c in runs if c["error"]), None)
    p04[label] = {"first_error": first_err, "n_ok": sum(1 for c in runs if c["error"] is None), "n_run": len(runs),
                  "summary": summary() if first_err is None else None, "result_json": result_json() if first_err is None else None}
    if first_err is None and label == "exif_rotated_photo":
        p04[label]["map_shape"] = list(ns["result"]["segmentation"].shape)
        p04[label]["image_size_seen"] = list(ns["image"].size)


if photo is not None:
    # (a) the COCO photo re-encoded as a JPEG with EXIF Orientation=6 (as a phone camera writes it)
    exif = Image.Exif()
    exif[0x0112] = 6
    rotated = photo.convert("RGB").transpose(Image.Transpose.ROTATE_90)  # stored sideways
    b = io.BytesIO()
    rotated.save(b, format="JPEG", exif=exif.tobytes(), quality=92)
    byod("exif_rotated_photo", {"phone.jpg": b.getvalue()}, downstream)
    # (b) a 16-bit greyscale PNG of the photo scaled to 0..65535
    import numpy as np

    g = np.asarray(photo.convert("L"), dtype=np.uint16) * 257
    b = io.BytesIO()
    Image.fromarray(g, mode="I;16").save(b, format="PNG")
    byod("png16_grey", {"grey16.png": b.getvalue()}, downstream)
    p04["png16_grey"]["rgb_after_convert_unique_values"] = int(len(np.unique(np.asarray(Image.open(io.BytesIO(b.getvalue())).convert("RGB")))))
# (c) too small
b = io.BytesIO()
Image.new("RGB", (10, 10), (0, 0, 0)).save(b, format="PNG")
byod("too_small_10px", {"tiny.png": b.getvalue()}, [11, 13])
# (d) not an image
byod("not_an_image", {"notes.txt": b"hello"}, [11])
# (e) cancelled / empty upload
byod("empty_upload", {}, [11])
results["P04_byod"] = p04
save()
print(json.dumps({k: (v if k != "P01_static" else {kk: vv for kk, vv in v.items() if kk != "keyword_counts_markdown"}) for k, v in results.items()}, indent=1, default=str)[:6000])
